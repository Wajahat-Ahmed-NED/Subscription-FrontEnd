import React from 'react'

function Inbox() {
    return (
        <div>
            <h1>INDEX PAGE</h1>
        </div>
    )
}

export default Inbox
