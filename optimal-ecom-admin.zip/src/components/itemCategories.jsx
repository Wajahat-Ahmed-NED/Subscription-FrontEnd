import React from 'react'

export default function ItemCategories() {
    return (
        <div>
            ItemCategories
        </div>
    )
}
