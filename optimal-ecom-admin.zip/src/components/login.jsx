import React, { useState, useContext } from 'react';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import CssBaseline from '@material-ui/core/CssBaseline';
import TextField from '@material-ui/core/TextField';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Grid from '@material-ui/core/Grid';
import Box from '@material-ui/core/Box';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';
import Container from '@material-ui/core/Container';
import { UserContext } from '../userContext';
import axios from "axios";
import { useDispatch, useSelector } from 'react-redux';

const useStyles = makeStyles((theme) => ({
  paper: {
    marginTop: theme.spacing(15),
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: "20px",
    borderRadius: "5px",
  },
  avatar: {
    margin: theme.spacing(1),
    backgroundColor: theme.palette.secondary.main,
  },
  form: {
    width: '100%', // Fix IE 11 issue.
    marginTop: theme.spacing(3),
  },
  submit: {
    margin: theme.spacing(3, 0, 2),
  },
}));

export default function Login({ onClick }) {
  const dispatch = useDispatch()
  const dataFromRedux = useSelector((a) => a)
  const classes = useStyles();
  const [email, setEmail] = useState('');
  const [password, setPasword] = useState('');
  const [data, setData] = useState('');
  const { setToken } = useContext(UserContext);

  async function logginIn(e) {
    e.preventDefault()

    const params = JSON.stringify({
      'email': email,
      'password': password,
    });
    await axios.post('http://localhost:3000/admin/login', params, {
      "headers": { "content-type": "application/json", },
    })
      .then(function (response) {
        console.log(response, 'asdasdasdjashshdjkashkdhaskjhvcv');
        localStorage.setItem("admin", JSON.stringify(response.data));
        setToken(response);
        setData(response.data)
        console.log(data)
        dispatch({ type: 'DATAFROMLOGIN', ...response.data })
        console.log(dataFromRedux)

      })
      .catch(function (error) {
        alert("Email or Password is incorrect")
        localStorage.clear();
      });
  };
  // console.log(dataFromRedux)
  // const logginIn = (event)=>{
  //   event.preventDefault();
  //   window.sessionStorage.setItem("email", email);
  //   window.sessionStorage.setItem("password", password);
  // };

  return (
    <Container component="main" maxWidth="xs">
      <CssBaseline />
      <Box
        boxShadow={2}
        bgcolor="background.paper"
      >
        <div className={classes.paper}>
          <Avatar className={classes.avatar}>
            <LockOutlinedIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Login
          </Typography>
          <form className={classes.form} onSubmit={logginIn} >
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <TextField
                  variant="outlined"
                  required
                  fullWidth
                  id="email"
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  label="Email Address"
                  name="email"
                  autoComplete="email"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  variant="outlined"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  value={password}
                  onChange={e => setPasword(e.target.value)}
                  type="password"
                  id="password"
                  autoComplete="current-password"
                />
              </Grid>
              <Grid item xs={12}>
                <FormControlLabel
                  control={<Checkbox value="allowExtraEmails" color="primary" />}
                  label="Remember Me."
                />
              </Grid>
            </Grid>
            <Grid container justify="center">
              <Button
                size="large"
                variant="outlined"
                color="primary"
                type="submit"
                className={classes.submit}
              >
                Sign IN
              </Button>
            </Grid>
          </form>
        </div>
      </Box>
    </Container>
  );
}