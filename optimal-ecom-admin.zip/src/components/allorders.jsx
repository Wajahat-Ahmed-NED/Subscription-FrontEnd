import React, { useContext, useEffect, useState } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import Backdrop from '@material-ui/core/Backdrop';
import Paper from '@material-ui/core/Paper';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import Typography from '@material-ui/core/Typography';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import CircularProgress from '@material-ui/core/CircularProgress';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import { Link, useHistory } from "react-router-dom";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
// import Button from '@mui/material/Button';

// import { logout } from './dashboard';
import { UserContext } from '../userContext';
import Modal from './modal';
import Newmodal from './newmodal';
import Modall from './modal';
import { WebEdit } from './webeditor';
import { isJwtExpired } from 'jwt-check-expiration';
import jwt from 'jsonwebtoken'
import { useDispatch, useSelector } from 'react-redux';
import axios, { Axios } from 'axios';
// import { UserContext } from '../userContext';



const columns = [
  {
    id: 'PKOrderID',
    label: 'OrderID',
    minWidth: 60,
  },
  // { id: 'FKCustomerID', label: 'FKCustomerID', minWidth: 100 },
  // {
  //   id: 'FKLabBranchID',
  //   label: 'FKLabBranchID',
  //   minWidth: 100,
  // },
  {
    id: 'Notes',
    label: 'Notes',
    minWidth: 60,
  },

  {
    id: 'Total',
    label: 'Total',
    minWidth: 60,
  },

  {
    id: 'CreatedDateTime',
    label: 'Created Date',
    minWidth: 60
  }, {
    label: 'Description',
    minWidth: 100
  },
  {
    label: 'Action',
    minWidth: 60
  },
  {
    id: 'Status',
    label: 'Status',
    minWidth: 50,
  }
];

const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
    zIndex: 0,
  },
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: '#fff',
  },
  container: {
    maxHeight: 500,
  },
}));
const styles = (theme) => ({
  root: {
    margin: 0,
    padding: theme.spacing(2),
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500],
  },
});
const DialogTitle = withStyles(styles)((props) => {
  const { children, classes, onClose, ...other } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root} {...other}>
      <Typography variant="h6">{children}</Typography>
      {onClose ? (
        <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});


const DialogContent = withStyles((theme) => ({
  root: {
    padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const DialogActions = withStyles((theme) => ({
  root: {
    margin: 0,
    padding: theme.spacing(1),
  },
}))(MuiDialogActions);

export default function ContactPage() {

  const dataFromRedux = useSelector((a) => a)
  // const dispatch = useDispatch()

  // const handleUpdate = () => {
  //   const obj = {
  //     name: 'ali',
  //     age: 12,
  //     apiData: [1, 2, 3, 4],
  //   }
  //   console.log(obj)
  //   dispatch({ type: 'DATAFROMAPI', ...obj })
  //   console.log(dataFromRedux)
  // }
  console.log(dataFromRedux)

  const classes = useStyles();


  const [page, setPage] = React.useState(0);
  const [rows, setRow] = useState([]);
  const [no, setNo] = useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [open, setOpen] = React.useState(false);
  const history = useHistory();
  const handleClickOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const [openNew, setOpenNew] = React.useState(false);

  const { setToken } = useContext(UserContext);
  useEffect(async () => {
    const adminToken = localStorage.getItem("admin");
    // console.log(adminToken)
    const token = JSON.parse(adminToken)?.tokens?.accessToken;
    const url = process.env.REACT_APP_URL
    const renewToken = JSON.parse(adminToken)?.tokens?.refreshToken;
    setOpenNew(true);

    if (isJwtExpired(renewToken) === false) {
      console.log('isExpired is:', isJwtExpired(token));

      if (isJwtExpired(token) === true) {
        const params = JSON.stringify({
          'refreshToken': renewToken,

        });
        try {
          const renewapi = `http://${url}/admin/renewAccessToken`
          await axios.post(renewapi, {
            'refreshToken': renewToken
          }, {
            headers: {
              Authorization: `Bearer ${token}`,
            }
          })

            .then(async response => {
              // console.log(response)
              // console.log(token)
              // console.log(JSON.parse(adminToken))
              let newToken = JSON.parse(adminToken)
              newToken.tokens.accessToken = response.data.NewAccessToken
              console.log(newToken)
              localStorage.setItem("admin", JSON.stringify(newToken))
              // const token = JSON.parse(adminToken)?.tokens?.accessToken;
              // localStorage.setItem("admin", adminToken)
              try {
                const api = `http://${url}/admin/orders`
                await axios.get(api, {
                  headers: {
                    Authorization: `Bearer ${token}`,
                  }
                })
                  // .then(response => response.json())
                  .then(json =>
                    setRow(json.data),
                    setOpenNew(false))

                  .catch(err => {
                    console.log(err)
                    setNo(1)
                  });
              }
              catch (err) {
                console.log(err)
              }
            }
            )
            // console.log()

            .catch(err => {
              console.log(err)
              setNo(1)
            });
        }
        catch (err) {
          console.log(err)
        }



      }
      else {
        try {
          const api = `http://${url}/admin/orders`
          await axios.get(api, {
            headers: {
              Authorization: `Bearer ${token}`,
            }
          })
            // .then(response => response.json())
            .then(json =>
              setRow(json.data),
              setOpenNew(false))

            .catch(err => {
              console.log(err)
              setNo(1)
            });
        }
        catch (err) {
          console.log(err)
        }
      }
    }

    else {
      setToken("")
      localStorage.clear();
      console.log('isExpired is:', isJwtExpired(token));
      alert("Session Time Out")
    }
  }, []);
  console.log(rows, "get ALL orders");

  const handleEditRow = (idEdit, row) => {
    let filteredRow = rows.filter(({ id }) => {
      return id !== idEdit
    })

    setRow([...filteredRow, row])
  }

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <>
      <h1 className='text-center mb-3'> Orders Details</h1>
      {/* <button className='btn btn-primary' onClick={handleUpdate}>Bootstrap</button> */}
      <div className="container d-flex justify-content-flex-end">
        <Modall btnTitle="Add" rows={rows} columns={columns} />
      </div>

      <Paper className={classes.root}>
        <Backdrop className={classes.backdrop} open={openNew}>
          <CircularProgress color="inherit" />
        </Backdrop>
        <div>
          <Dialog onClose={handleClose} aria-labelledby="customized-dialog-title" open={open}>
            <DialogTitle id="customized-dialog-title" onClose={handleClose}>
              Modal title
            </DialogTitle>
            <DialogContent dividers>
              <form className={classes.form} noValidate>
                <Grid container spacing={2}>
                  <Grid item xs={12}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      id="email"
                      label="Email Address"
                      name="email"
                      autoComplete="email"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      name="text"
                      label="TEXT"
                      type="text"
                      id="password"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      name="text"
                      label="TEXT"
                      type="text"
                      id="password"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <TextField
                      variant="outlined"
                      required
                      fullWidth
                      name="password"
                      label="Password"
                      type="password"
                      id="password"
                      autoComplete="current-password"
                    />
                  </Grid>
                  <Grid item xs={12}>
                  </Grid>
                </Grid>
              </form>
            </DialogContent>
            <DialogActions>
              <Button autoFocus onClick={handleClose} color="primary">
                Save changes
              </Button>
            </DialogActions>
          </Dialog>
        </div>
        <TableContainer className={classes.container}>
          <Table stickyHeader aria-label="sticky table">
            <TableHead>
              <TableRow>
                {columns.map((column) => (
                  <TableCell
                    key={column.id}
                    align={column.align}
                    style={{ minWidth: column.minWidth }} className={column.label === "Action" && 'text-center'}
                  >
                    {column.label}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {isJwtExpired && rows && Array.isArray(rows) && rows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((row) => {
                return (
                  //onClick={handleClickOpen}
                  <TableRow className="hovereffects"
                    //  onClick={() =>
                    //   history.push({
                    //     pathname: "/Report",
                    //     state: row?.PKOrderID,
                    //   }
                    //   )
                    // }
                    hover role="checkbox" tabIndex={-1} key={row.code}>
                    {columns.map((column) => {

                      const value = column.id === "CreatedDateTime" ? row[column.id].slice(0, 10) : row[column.id]
                      return (
                        <TableCell key={column.id} align={column.align} >
                          {column.format && typeof value === 'number' ? column.format(value) : value === "Pending" ? <CheckCircleIcon color="success" /> : column.label === "Action" ? <><Modal btnTitle="Edit" rows={row} columns={columns} handleEditRow={handleEditRow} />
                            <Modal btnTitle="Delete" /> </> : column.label === "Description" ? <WebEdit /> : value}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                );
              })
              }
            </TableBody>
          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[10, 25, 100]}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
        {/* <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
</div> */}
        {/* <!-- Button trigger modal --> */}

      </Paper>
    </>
  );
}
