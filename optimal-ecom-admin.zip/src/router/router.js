import React from "react";
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from "react-router-dom";
import Dashboard from "../components/dashboard";
import Login from "../components/login";

export default function AppRouter() {
    return (
        <Router>
            <div>

                {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}
                <Switch>
                    <Route exact path="/login" component={Login} />
                    {/* <Route path="/dashboard" component={Dashboard} /> */}
                    {/* <Route path="/webedit" component={s} /> */}


                </Switch>
            </div>
        </Router>
    );
}